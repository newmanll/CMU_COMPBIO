const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

export async function runAlignment(payload) {
  const res = await fetch(`${API_URL}/api/align`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.error || `Request failed with status ${res.status}`);
  }
  return data;
}
