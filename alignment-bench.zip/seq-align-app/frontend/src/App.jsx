import { useState } from "react";
import SequenceInput from "./components/SequenceInput.jsx";
import Controls from "./components/Controls.jsx";
import AlignmentResult from "./components/AlignmentResult.jsx";
import { runAlignment } from "./api.js";
import "./App.css";

const EXAMPLES = {
  dna: {
    seq1: "GATTACAGATTACA",
    seq2: "GCATGCUGATTACA",
  },
  protein: {
    seq1: "MKTAYIAKQRQISFVKSHFSRQLEERLGLIEVQ",
    seq2: "MKTAYIAKQRQISFIKSHFSRQLEERLGLIEVQ",
  },
};

export default function App() {
  const [seq1, setSeq1] = useState("");
  const [seq2, setSeq2] = useState("");
  const [params, setParams] = useState({
    seqType: "dna",
    algorithm: "global",
    match: 1,
    mismatch: -1,
    gap: -2,
  });
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const loadExample = () => {
    const ex = EXAMPLES[params.seqType];
    setSeq1(ex.seq1);
    setSeq2(ex.seq2);
  };

  const handleRun = async () => {
    setError(null);
    setResult(null);
    setLoading(true);
    try {
      const data = await runAlignment({
        seq1,
        seq2,
        seqType: params.seqType,
        algorithm: params.algorithm,
        match: Number(params.match),
        mismatch: Number(params.mismatch),
        gap: Number(params.gap),
      });
      setResult(data);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page">
      <header className="hero">
        <span className="hero__eyebrow">Pairwise sequence alignment</span>
        <h1 className="hero__title">Alignment Bench</h1>
        <p className="hero__tagline">
          Lay two sequences side by side and let Needleman-Wunsch or Smith-Waterman
          find how they line up — nucleotide by nucleotide, residue by residue.
        </p>
      </header>

      <main className="bench">
        <div className="bench__specimens">
          <SequenceInput
            label="Sequence A"
            slot="A"
            value={seq1}
            onChange={setSeq1}
            placeholder={params.seqType === "dna" ? "e.g. ATGCGTACGTTAGC" : "e.g. MKTAYIAKQRQISFVKSHFSRQ"}
          />
          <SequenceInput
            label="Sequence B"
            slot="B"
            value={seq2}
            onChange={setSeq2}
            placeholder={params.seqType === "dna" ? "e.g. ATGCGTACCTTAGC" : "e.g. MKTAYIAKQRQISFIKSHFSRQ"}
          />
        </div>

        <button type="button" className="example-link" onClick={loadExample}>
          Load an example pair →
        </button>

        <Controls params={params} setParams={setParams} onRun={handleRun} loading={loading} />

        {error && <div className="error-banner">{error}</div>}

        {result && <AlignmentResult result={result} seqType={params.seqType} />}
      </main>

      <footer className="footer">
        <p>
          Scoring uses a linear gap penalty. DNA/RNA comparisons treat U and T as
          equivalent. Protein alignments use BLOSUM62 substitution scores.
        </p>
      </footer>
    </div>
  );
}
