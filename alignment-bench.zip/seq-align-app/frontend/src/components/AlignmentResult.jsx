const BASE_CLASS = {
  A: "base-a",
  C: "base-c",
  G: "base-g",
  T: "base-t",
  U: "base-t",
  "-": "base-gap",
};

function baseClass(char, seqType) {
  if (char === "-") return "base-gap";
  if (seqType === "dna") return BASE_CLASS[char.toUpperCase()] || "base-neutral";
  return "base-neutral";
}

function Track({ line, seqType }) {
  return (
    <div className="track">
      {[...line].map((ch, i) => (
        <span key={i} className={`track__cell ${baseClass(ch, seqType)}`}>
          {ch}
        </span>
      ))}
    </div>
  );
}

function chunk(str, size) {
  const out = [];
  for (let i = 0; i < str.length; i += size) out.push(str.slice(i, i + size));
  return out;
}

export default function AlignmentResult({ result, seqType }) {
  if (!result) return null;

  const width = 60;
  const rows1 = chunk(result.aligned1, width);
  const rows2 = chunk(result.aligned2, width);
  const rowsM = chunk(result.match_line, width);

  return (
    <div className="result">
      <div className="result__stats">
        <div className="stat">
          <span className="stat__value">{result.score}</span>
          <span className="stat__label">Score</span>
        </div>
        <div className="stat">
          <span className="stat__value">{result.identity_pct}%</span>
          <span className="stat__label">Identity</span>
        </div>
        <div className="stat">
          <span className="stat__value">{result.aligned1.length}</span>
          <span className="stat__label">Aligned length</span>
        </div>
        <div className="stat">
          <span className="stat__value">{result.algorithm === "global" ? "Global" : "Local"}</span>
          <span className="stat__label">Alignment</span>
        </div>
      </div>

      <div className="result__tracks">
        {rows1.map((_, idx) => (
          <div className="track-row" key={idx}>
            <Track line={rows1[idx]} seqType={seqType} />
            <div className="track track--match">
              {[...rowsM[idx]].map((ch, i) => (
                <span key={i} className="track__cell track__cell--match">
                  {ch}
                </span>
              ))}
            </div>
            <Track line={rows2[idx]} seqType={seqType} />
          </div>
        ))}
      </div>
    </div>
  );
}
