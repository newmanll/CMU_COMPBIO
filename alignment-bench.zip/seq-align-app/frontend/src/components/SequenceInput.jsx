export default function SequenceInput({ label, slot, value, onChange, placeholder }) {
  const cleanLength = value.replace(/[^A-Za-z]/g, "").length;

  return (
    <div className="specimen">
      <div className="specimen__head">
        <span className="specimen__slot">{slot}</span>
        <span className="specimen__label">{label}</span>
        <span className="specimen__count">{cleanLength} residues</span>
      </div>
      <textarea
        className="specimen__textarea"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        spellCheck={false}
        rows={5}
      />
    </div>
  );
}
