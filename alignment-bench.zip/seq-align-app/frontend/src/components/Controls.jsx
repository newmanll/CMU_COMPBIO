export default function Controls({ params, setParams, onRun, loading }) {
  const update = (key, val) => setParams((p) => ({ ...p, [key]: val }));

  return (
    <div className="controls">
      <div className="controls__group" role="group" aria-label="Sequence type">
        <span className="controls__eyebrow">01 — Type</span>
        <div className="toggle">
          {[
            ["dna", "DNA / RNA"],
            ["protein", "Protein"],
          ].map(([val, text]) => (
            <button
              key={val}
              type="button"
              className={`toggle__btn ${params.seqType === val ? "is-active" : ""}`}
              onClick={() => update("seqType", val)}
            >
              {text}
            </button>
          ))}
        </div>
      </div>

      <div className="controls__group" role="group" aria-label="Algorithm">
        <span className="controls__eyebrow">02 — Algorithm</span>
        <div className="toggle">
          {[
            ["global", "Global · Needleman-Wunsch"],
            ["local", "Local · Smith-Waterman"],
          ].map(([val, text]) => (
            <button
              key={val}
              type="button"
              className={`toggle__btn ${params.algorithm === val ? "is-active" : ""}`}
              onClick={() => update("algorithm", val)}
            >
              {text}
            </button>
          ))}
        </div>
      </div>

      <div className="controls__group">
        <span className="controls__eyebrow">03 — Scoring</span>
        <div className="scoring">
          {params.seqType === "dna" ? (
            <>
              <label className="scoring__field">
                Match
                <input
                  type="number"
                  value={params.match}
                  onChange={(e) => update("match", e.target.value)}
                />
              </label>
              <label className="scoring__field">
                Mismatch
                <input
                  type="number"
                  value={params.mismatch}
                  onChange={(e) => update("mismatch", e.target.value)}
                />
              </label>
            </>
          ) : (
            <span className="scoring__note">Using BLOSUM62 substitution scores</span>
          )}
          <label className="scoring__field">
            Gap
            <input
              type="number"
              value={params.gap}
              onChange={(e) => update("gap", e.target.value)}
            />
          </label>
        </div>
      </div>

      <button className="run-btn" onClick={onRun} disabled={loading}>
        {loading ? "Aligning…" : "Run alignment"}
      </button>
    </div>
  );
}
