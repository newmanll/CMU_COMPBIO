import re

from flask import Flask, jsonify, request
from flask_cors import CORS

from algorithms import align

app = Flask(__name__)
CORS(app)

DNA_RE = re.compile(r"^[ACGTUNacgtun\s\-]+$")
PROTEIN_RE = re.compile(r"^[ACDEFGHIKLMNPQRSTVWYBZXacdefghiklmnpqrstvwybzx\s\-\*]+$")


def clean_sequence(raw):
    """Strip FASTA headers/whitespace/newlines, uppercase the result."""
    if raw is None:
        return ""
    lines = [ln for ln in raw.strip().splitlines() if not ln.startswith(">")]
    return re.sub(r"\s+", "", "".join(lines)).upper()


@app.get("/api/health")
def health():
    return jsonify({"status": "ok"})


@app.post("/api/align")
def api_align():
    data = request.get_json(silent=True) or {}

    seq1 = clean_sequence(data.get("seq1", ""))
    seq2 = clean_sequence(data.get("seq2", ""))
    seq_type = data.get("seqType", "dna")
    algorithm = data.get("algorithm", "global")

    try:
        match = int(data.get("match", 1))
        mismatch = int(data.get("mismatch", -1))
        gap = int(data.get("gap", -2))
    except (TypeError, ValueError):
        return jsonify({"error": "match, mismatch and gap must be integers."}), 400

    if seq_type not in ("dna", "protein"):
        return jsonify({"error": "seqType must be 'dna' or 'protein'."}), 400
    if algorithm not in ("global", "local"):
        return jsonify({"error": "algorithm must be 'global' or 'local'."}), 400
    if not seq1 or not seq2:
        return jsonify({"error": "Both sequences are required."}), 400
    if len(seq1) > 5000 or len(seq2) > 5000:
        return jsonify({"error": "Sequences must be 5000 characters or fewer."}), 400

    validator = DNA_RE if seq_type == "dna" else PROTEIN_RE
    if not validator.match(seq1) or not validator.match(seq2):
        return jsonify({"error": f"Input contains characters invalid for a {seq_type} sequence."}), 400

    try:
        result = align(seq1, seq2, algorithm=algorithm, seq_type=seq_type,
                        match=match, mismatch=mismatch, gap=gap)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400

    identity = sum(1 for a, b in zip(result["aligned1"], result["aligned2"]) if a == b)
    aligned_len = len(result["aligned1"]) or 1
    result["identity_pct"] = round(100 * identity / aligned_len, 1)
    result["length1"] = len(seq1)
    result["length2"] = len(seq2)

    return jsonify(result)


if __name__ == "__main__":
    app.run(debug=True, port=5000)
