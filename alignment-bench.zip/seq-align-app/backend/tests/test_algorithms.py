import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from algorithms import needleman_wunsch, smith_waterman


def test_global_identical_sequences():
    result = needleman_wunsch("ACGT", "ACGT", seq_type="dna")
    assert result["aligned1"] == "ACGT"
    assert result["aligned2"] == "ACGT"
    assert result["score"] == 4


def test_global_with_gap():
    result = needleman_wunsch("GATTACA", "GCATGCU", seq_type="dna", match=1, mismatch=-1, gap=-1)
    assert len(result["aligned1"]) == len(result["aligned2"])
    assert "-" not in result["aligned1"] or "-" not in result["aligned2"] or True


def test_local_finds_best_subsequence():
    result = smith_waterman("AAAGGGCCCTTT", "GGGCCC", seq_type="dna")
    assert result["aligned1"] == "GGGCCC"
    assert result["aligned2"] == "GGGCCC"
    assert result["score"] == 6


def test_protein_alignment_runs():
    result = needleman_wunsch("MKTAYIAK", "MKTAYIAK", seq_type="protein")
    assert result["score"] > 0
    assert result["aligned1"] == "MKTAYIAK"


def test_rna_dna_equivalence():
    result = needleman_wunsch("ACGU", "ACGT", seq_type="dna")
    assert result["score"] == 4  # U treated as equivalent to T
