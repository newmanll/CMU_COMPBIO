"""Pairwise sequence alignment algorithms: Needleman-Wunsch (global) and
Smith-Waterman (local). Both use a linear gap penalty and a pluggable
scoring function so the same code handles DNA/RNA and protein input.
"""

from matrices import get_scorer

DIAG, UP, LEFT, STOP = "D", "U", "L", "S"


def _build_match_line(a_line, b_line, seq_type):
    """Build the middle annotation line: '|' for identical, ':' for a
    positive-scoring protein substitution, ' ' otherwise/gap.
    """
    scorer = get_scorer(seq_type)
    out = []
    for x, y in zip(a_line, b_line):
        if x == "-" or y == "-":
            out.append(" ")
        elif x.upper() == y.upper() or (x.upper() == "U" and y.upper() == "T") or (x.upper() == "T" and y.upper() == "U"):
            out.append("|")
        elif seq_type == "protein" and scorer(x, y) > 0:
            out.append(":")
        else:
            out.append(" ")
    return "".join(out)


def needleman_wunsch(seq1, seq2, seq_type="dna", match=1, mismatch=-1, gap=-2):
    """Global alignment. Returns dict with aligned1, aligned2, match_line, score."""
    scorer = get_scorer(seq_type, match, mismatch)
    n, m = len(seq1), len(seq2)

    score = [[0] * (m + 1) for _ in range(n + 1)]
    trace = [[STOP] * (m + 1) for _ in range(n + 1)]

    for i in range(1, n + 1):
        score[i][0] = score[i - 1][0] + gap
        trace[i][0] = UP
    for j in range(1, m + 1):
        score[0][j] = score[0][j - 1] + gap
        trace[0][j] = LEFT

    for i in range(1, n + 1):
        for j in range(1, m + 1):
            diag = score[i - 1][j - 1] + scorer(seq1[i - 1], seq2[j - 1])
            up = score[i - 1][j] + gap
            left = score[i][j - 1] + gap
            best = max(diag, up, left)
            score[i][j] = best
            trace[i][j] = DIAG if best == diag else (UP if best == up else LEFT)

    # Traceback from bottom-right corner
    aligned1, aligned2 = [], []
    i, j = n, m
    while i > 0 or j > 0:
        move = trace[i][j] if i > 0 and j > 0 else (UP if j == 0 else LEFT)
        if i == 0:
            move = LEFT
        elif j == 0:
            move = UP
        if move == DIAG:
            aligned1.append(seq1[i - 1])
            aligned2.append(seq2[j - 1])
            i -= 1
            j -= 1
        elif move == UP:
            aligned1.append(seq1[i - 1])
            aligned2.append("-")
            i -= 1
        else:
            aligned1.append("-")
            aligned2.append(seq2[j - 1])
            j -= 1

    aligned1.reverse()
    aligned2.reverse()
    a_line = "".join(aligned1)
    b_line = "".join(aligned2)

    return {
        "aligned1": a_line,
        "aligned2": b_line,
        "match_line": _build_match_line(a_line, b_line, seq_type),
        "score": score[n][m],
        "algorithm": "global",
    }


def smith_waterman(seq1, seq2, seq_type="dna", match=1, mismatch=-1, gap=-2):
    """Local alignment. Returns dict with aligned1, aligned2, match_line, score,
    plus the start/end positions of the aligned region in each original sequence.
    """
    scorer = get_scorer(seq_type, match, mismatch)
    n, m = len(seq1), len(seq2)

    score = [[0] * (m + 1) for _ in range(n + 1)]
    trace = [[STOP] * (m + 1) for _ in range(n + 1)]

    best_score = 0
    best_pos = (0, 0)

    for i in range(1, n + 1):
        for j in range(1, m + 1):
            diag = score[i - 1][j - 1] + scorer(seq1[i - 1], seq2[j - 1])
            up = score[i - 1][j] + gap
            left = score[i][j - 1] + gap
            best = max(0, diag, up, left)
            score[i][j] = best
            if best == 0:
                trace[i][j] = STOP
            elif best == diag:
                trace[i][j] = DIAG
            elif best == up:
                trace[i][j] = UP
            else:
                trace[i][j] = LEFT
            if best > best_score:
                best_score = best
                best_pos = (i, j)

    aligned1, aligned2 = [], []
    i, j = best_pos
    end1, end2 = i, j
    while i > 0 and j > 0 and trace[i][j] != STOP:
        move = trace[i][j]
        if move == DIAG:
            aligned1.append(seq1[i - 1])
            aligned2.append(seq2[j - 1])
            i -= 1
            j -= 1
        elif move == UP:
            aligned1.append(seq1[i - 1])
            aligned2.append("-")
            i -= 1
        else:
            aligned1.append("-")
            aligned2.append(seq2[j - 1])
            j -= 1

    start1, start2 = i, j
    aligned1.reverse()
    aligned2.reverse()
    a_line = "".join(aligned1)
    b_line = "".join(aligned2)

    return {
        "aligned1": a_line,
        "aligned2": b_line,
        "match_line": _build_match_line(a_line, b_line, seq_type),
        "score": best_score,
        "algorithm": "local",
        "range1": [start1, end1],
        "range2": [start2, end2],
    }


def align(seq1, seq2, algorithm="global", seq_type="dna", match=1, mismatch=-1, gap=-2):
    if not seq1 or not seq2:
        raise ValueError("Both sequences must be non-empty.")
    fn = needleman_wunsch if algorithm == "global" else smith_waterman
    return fn(seq1, seq2, seq_type=seq_type, match=match, mismatch=mismatch, gap=gap)
