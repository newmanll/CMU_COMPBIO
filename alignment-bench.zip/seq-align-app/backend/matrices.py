"""Substitution matrices used for scoring alignments."""

# Standard BLOSUM62 matrix (amino acid substitution scores).
_BLOSUM62_ORDER = list("ARNDCQEGHILKMFPSTWYVBZX*")

_BLOSUM62_ROWS = [
    "  4 -1 -2 -2  0 -1 -1  0 -2 -1 -1 -1 -1 -2 -1  1  0 -3 -2  0 -2 -1  0 -4",
    " -1  5  0 -2 -3  1  0 -2  0 -3 -2  2 -1 -3 -2 -1 -1 -3 -2 -3 -1  0 -1 -4",
    " -2  0  6  1 -3  0  0  0  1 -3 -3  0 -2 -3 -2  1  0 -4 -2 -3  3  0 -1 -4",
    " -2 -2  1  6 -3  0  2 -1 -1 -3 -4 -1 -3 -3 -1  0 -1 -4 -3 -3  4  1 -1 -4",
    "  0 -3 -3 -3  9 -3 -4 -3 -3 -1 -1 -3 -1 -2 -3 -1 -1 -2 -2 -1 -3 -3 -2 -4",
    " -1  1  0  0 -3  5  2 -2  0 -3 -2  1  0 -3 -1  0 -1 -2 -1 -2  0  3 -1 -4",
    " -1  0  0  2 -4  2  5 -2  0 -3 -3  1 -2 -3 -1  0 -1 -3 -2 -2  1  4 -1 -4",
    "  0 -2  0 -1 -3 -2 -2  6 -2 -4 -4 -2 -3 -3 -2  0 -2 -2 -3 -3 -1 -2 -1 -4",
    " -2  0  1 -1 -3  0  0 -2  8 -3 -3 -1 -2 -1 -2 -1 -2 -2  2 -3  0  0 -1 -4",
    " -1 -3 -3 -3 -1 -3 -3 -4 -3  4  2 -3  1  0 -3 -2 -1 -3 -1  3 -3 -3 -1 -4",
    " -1 -2 -3 -4 -1 -2 -3 -4 -3  2  4 -2  2  0 -3 -2 -1 -2 -1  1 -4 -3 -1 -4",
    " -1  2  0 -1 -3  1  1 -2 -1 -3 -2  5 -1 -3 -1  0 -1 -3 -2 -2  0  1 -1 -4",
    " -1 -1 -2 -3 -1  0 -2 -3 -2  1  2 -1  5  0 -2 -1 -1 -1 -1  1 -3 -1 -1 -4",
    " -2 -3 -3 -3 -2 -3 -3 -3 -1  0  0 -3  0  6 -4 -2 -2  1  3 -1 -3 -3 -1 -4",
    " -1 -2 -2 -1 -3 -1 -1 -2 -2 -3 -3 -1 -2 -4  7 -1 -1 -4 -3 -2 -2 -1 -2 -4",
    "  1 -1  1  0 -1  0  0  0 -1 -2 -2  0 -1 -2 -1  4  1 -3 -2 -2  0  0  0 -4",
    "  0 -1  0 -1 -1 -1 -1 -2 -2 -1 -1 -1 -1 -2 -1  1  5 -2 -2  0 -1 -1  0 -4",
    " -3 -3 -4 -4 -2 -2 -3 -2 -2 -3 -2 -3 -1  1 -4 -3 -2 11  2 -3 -4 -3 -2 -4",
    " -2 -2 -2 -3 -2 -1 -2 -3  2 -1 -1 -2 -1  3 -3 -2 -2  2  7 -1 -3 -2 -1 -4",
    "  0 -3 -3 -3 -1 -2 -2 -3 -3  3  1 -2  1 -1 -2 -2  0 -3 -1  4 -3 -2 -1 -4",
    " -2 -1  3  4 -3  0  1 -1  0 -3 -4  0 -3 -3 -2  0 -1 -4 -3 -3  4  1 -1 -4",
    " -1  0  0  1 -3  3  4 -2  0 -3 -3  1 -1 -3 -1  0 -1 -3 -2 -2  1  4 -1 -4",
    "  0 -1 -1 -1 -2 -1 -1 -1 -1 -1 -1 -1 -1 -1 -2  0  0 -2 -1 -1 -1 -1 -1 -4",
    " -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4 -4  1",
]

BLOSUM62 = {}
for _row_letter, _row_str in zip(_BLOSUM62_ORDER, _BLOSUM62_ROWS):
    _scores = [int(x) for x in _row_str.split()]
    for _col_letter, _score in zip(_BLOSUM62_ORDER, _scores):
        BLOSUM62[(_row_letter, _col_letter)] = _score


def protein_score(a, b, match=None, mismatch=None):
    """Look up a BLOSUM62 score for two residues (case-insensitive)."""
    a, b = a.upper(), b.upper()
    if (a, b) in BLOSUM62:
        return BLOSUM62[(a, b)]
    # Unknown residue -> treat as neutral 'X'
    return BLOSUM62.get(("X", "X"), -1)


def nucleotide_score(a, b, match=1, mismatch=-1):
    """Simple match/mismatch scoring for DNA/RNA, case-insensitive.
    Treats U and T as equivalent so RNA and DNA can be compared directly.
    """
    norm = lambda c: "T" if c.upper() == "U" else c.upper()
    return match if norm(a) == norm(b) else mismatch


def get_scorer(seq_type, match=1, mismatch=-1):
    """Return a scoring function score(a, b) -> int for the given sequence type."""
    if seq_type == "protein":
        return lambda a, b: protein_score(a, b)
    return lambda a, b: nucleotide_score(a, b, match, mismatch)
